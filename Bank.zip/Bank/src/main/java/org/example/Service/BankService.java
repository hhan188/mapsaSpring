package org.example.Service;

import org.example.Entities.Bank;

public class BankService extends BaseService<Bank>{
    public BankService() {
        super(Bank.class);
    }
}
