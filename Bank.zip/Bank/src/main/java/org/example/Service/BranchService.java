package org.example.Service;

import org.example.Entities.Branch;

public class BranchService extends BaseService<Branch>{
    public BranchService() {
        super(Branch.class);
    }
}
