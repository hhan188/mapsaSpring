package org.example.Service;

import org.example.Entities.Account;

public class AccountService extends BaseService<Account>{


    public AccountService() {
        super(Account.class);
    }
}
