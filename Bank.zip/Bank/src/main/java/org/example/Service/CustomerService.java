package org.example.Service;

import org.example.Entities.Customer;

public class CustomerService extends BaseService<Customer>{
    public CustomerService() {
        super(Customer.class);
    }
}
