package org.example.Service;

import org.example.SessionFactoryProvider;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public abstract class BaseService<T> {
    private SessionFactory sessionFactory;
    private final Class<T> type;

    public BaseService( Class<T> type) {
        sessionFactory = SessionFactoryProvider.getSessionfactory();
        this.type = type;
    }
    public void create(T entity){
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.save(entity);
        session.getTransaction().commit();
        session.close();
    }
    public void update(T entity){
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.update(entity);
        session.getTransaction().commit();
        session.close();
    }
    public void delete(T entity){
        Session session = sessionFactory.openSession();
        session.beginTransaction();
        session.delete(entity);
        session.getTransaction().commit();
        session.close();
    }
    public T getById(Integer id){
        Session session = sessionFactory.openSession();
        T entity = session.get(type , id);
        session.close();
        return entity;
    }

}
