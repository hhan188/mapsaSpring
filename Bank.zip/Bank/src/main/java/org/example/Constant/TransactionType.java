package org.example.Constant;

public enum TransactionType {
    Deposit, WithDraw
}
