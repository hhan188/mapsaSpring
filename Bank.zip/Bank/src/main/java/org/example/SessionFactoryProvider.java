package org.example;

import org.example.Entities.Account;
import org.example.Entities.Bank;
import org.example.Entities.Branch;
import org.example.Entities.Customer;
import org.hibernate.SessionFactory;
import org.example.Entities.Transaction;
import org.hibernate.cfg.Configuration;

public class SessionFactoryProvider
{
    private static SessionFactory sf;
    public static SessionFactory getSessionfactory(){
        if (sf == null){
            Configuration cfg = new Configuration();
            cfg.addAnnotatedClass(Account.class);
            cfg.addAnnotatedClass(Bank.class);
            cfg.addAnnotatedClass(Branch.class);
            cfg.addAnnotatedClass(Customer.class);
            cfg.addAnnotatedClass(Transaction.class);
            sf = cfg.buildSessionFactory();
            return sf;
        }
        return sf;
    }

}
