package org.example;

import org.example.Constant.TransactionType;
import org.example.Entities.*;
import org.example.Service.AccountService;
import org.example.Service.BankService;
import org.example.Service.BranchService;
import org.example.Service.CustomerService;

import java.util.List;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
//        AccountService accountService = new AccountService();
//        BranchService branchService = new BranchService();
        CustomerService customerService = new CustomerService();
        BankService bankService = new BankService();

       Bank bank = new Bank("pasargad");

       Branch branch = new Branch("Tehran");
        Branch branch1 = new Branch("Esfehn");

       Account account = new Account(50222910);
       Account account1= new Account(3434000);
       Account account2 = new Account(54545454);
       Account account3 = new Account(676776676);

       Customer customer = new Customer(21122);
       Customer customer1 = new Customer(333321);
        Customer customer2 = new Customer(443321);
        Customer customer3 = new Customer(663321);



        Transaction transaction = new Transaction(TransactionType.Deposit);
       Transaction transaction1 = new Transaction(TransactionType.WithDraw);
       Transaction transaction2 = new Transaction(TransactionType.WithDraw);
       Transaction transaction3 = new Transaction(TransactionType.Deposit);

       bank.getBranches().add(branch);
       bank.getBranches().add(branch1);

       branch.setBank(bank);
       branch1.setBank(bank);
       branch.getAccounts().add(account);
       branch.getAccounts().add(account1);
       branch1.getAccounts().add(account2);
       branch1.getAccounts().add(account3);

       account.getCustomers().add(customer);
       account.getCustomers().add(customer1);
       account2.getCustomers().add(customer2);
       account3.getCustomers().add(customer3);
       account.setCustomers(Set.of(customer1,customer));
       account2.setCustomers(Set.of(customer2));
       account3.setCustomers(Set.of(customer3));

       account.setBranch(branch);
       account1.setBranch(branch);
       account2.setBranch(branch1);
       account3.setBranch(branch1);

       account.getTransactions().add(transaction);
       account.getTransactions().add(transaction1);
       account3.getTransactions().add(transaction2);
       account2.getTransactions().add(transaction3);


       transaction.setAccount(account);
       transaction1.setAccount(account1);
       transaction3.setAccount(account2);
       transaction2.setAccount(account3);

       customer.getAccounts().add(account);
       customer1.getAccounts().add(account1);
       customer2.getAccounts().add(account2);
       customer3.getAccounts().add(account3);

       bankService.create(bank);
       customerService.create(customer);
    }

    public static void ehsan(){
        AccountService accountService = new AccountService();
        BranchService branchService = new BranchService();
        CustomerService customerService = new CustomerService();
        BankService bankService = new BankService();
        Account account1 = new Account(213213312);
        Account account2 = new Account(7669769);

        Bank bank = new Bank("Pasargad");

        Branch branch1 = new Branch("2122121");
        Branch branch2 = new Branch("111121212");

        Customer customer1 = new Customer(00222);
        Customer customer2 = new Customer(1112222);

        Transaction transaction1 = new Transaction(TransactionType.Deposit);
        Transaction transaction2 = new Transaction(TransactionType.WithDraw);

        branch1.setBank(bank);
        branch2.setBank(bank);
        bank.setBranches(Set.of(branch1,branch2));

        transaction2.setAccount(account1);
        transaction1.setAccount(account1);
        account1.setTransactions(List.of(transaction1,transaction2));

        transaction2.setAccount(account2);
        transaction1.setAccount(account2);
        account2.setTransactions(List.of(transaction1,transaction2));


        account2.setBranch(branch1);
        account1.setBranch(branch1);
        branch1.setAccounts(Set.of(account1,account2));


        account2.setBranch(branch2);
        account1.setBranch(branch2);
        branch1.setAccounts(Set.of(account1,account2));

        account2.setCustomers(Set.of(customer1,customer2));
        account1.setCustomers(Set.of(customer1,customer2));

        customer2.setAccounts(Set.of(account1,account2));
        customer1.setAccounts(Set.of(account1,account2));

        branchService.create(branch1);
        branchService.create(branch2);

        accountService.create(account1);
        accountService.create(account2);

        customerService.create(customer1);
        customerService.create(customer2);
    }
}